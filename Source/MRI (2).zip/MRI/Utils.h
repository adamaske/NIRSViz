#pragma once

namespace NVMRI {
  
}