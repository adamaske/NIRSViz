#pragma once
#include <vector>
#include "Core/Base.h"
#include "MRI/MRIImage.h"

#include "Renderer/Buffer/VertexArray.h"
#include "Renderer/Buffer/IndexBuffer.h"
#include "Renderer/Buffer/VertexBuffer.h"

#include "Renderer/Renderable/Shader.h"
#include "Renderer/Renderable/Texture.h"

#include "App/Data/Transform.h"

enum class SlicePlane {
	Axial,
	Saggital,
	Coronal
};

struct Slice {

	Transform transform;

	SlicePlane plane = SlicePlane::Axial;

};

namespace NVMRI {

	class MRISliceViewer {
	public:
	

		void OnAttach(NVMRI::MRIImage* mri_image);
		void OnUpdate(DeltaTime dt);
		void Render(bool standalone);		

		void DrawSlice(Slice& slice);

		std::vector<Slice> slices_;

		MRIImage* mri_image_ = nullptr;

		Ref<VertexArray> plane_vao_;
		Ref<VertexBuffer> plane_vbo_;
		Ref<IndexBuffer> plane_ibo_;

		Ref<Shader> slice_shader_;
		Ref<Texture> slice_texture_;
	};
}