#include "pch.h"
#include "MRI/MRISliceViewer.h"

#include <imgui.h>
#include "GUI/GUI.h"

namespace NVMRI {

	void MRISliceViewer::OnAttach(NVMRI::MRIImage* mri_image) {
		mri_image_ = mri_image;

		// ITK image pointer =
		mri_image_->itkImage;
		// we have
		

		// We need to read the mri_image to check the dimensions 
		// of the slices and the spacing 
		// between them to correctly position the planes in 3D space. 
		// For now we will assume the image is centered at the origin 
		// and has a spacing of 1.0 in all dimensions.

		// Create 3 Transforms for each plane

		// Axial - Red Axis Seperates Superier from Inferior
		// Saggital - Yellow Axis Seperates Left from Right
		// Coronal - Green Axis Seperates Anterior from Posterior

		slices_[0].plane = SlicePlane::Axial;
		slices_[1].plane = SlicePlane::Saggital;
		slices_[2].plane = SlicePlane::Coronal;

		slices_[0].transform.SetPosition(glm::vec3(0.0f, 0.0f, 0.0f));
		slices_[1].transform.SetPosition(glm::vec3(0.0f, 0.0f, 0.0f));
		slices_[2].transform.SetPosition(glm::vec3(0.0f, 0.0f, 0.0f));

		slices_[0].transform.SetRotation(glm::vec3(0.0f, 0.0f, 0.0f));
		slices_[1].transform.SetRotation(glm::vec3(0.0f, 0.0f, 0.0f));
		slices_[2].transform.SetRotation(glm::vec3(0.0f, 0.0f, 0.0f));

		// Create Vertex Array and Index Buffer
		plane_vao_ = CreateRef<VertexArray>();
		plane_vbo_ = CreateRef<VertexBuffer>(/* Vertex data for a plane */);
		plane_ibo_ = CreateRef<IndexBuffer>(/* Index data for a plane */);

		plane_vbo_->SetLayout({
			{ ShaderDataType::Float3, "a_Position" },
			{ ShaderDataType::Float2, "a_TexCoord" }
			});

		//plane_vbo_->SetData(/* Vertex data for a plane */);
		//
		//plane_ibo_->SetData(/* Index data for a plane */);

		// Store the MRI image reference
		plane_vao_->AddVertexBuffer(plane_vbo_);
		plane_vao_->SetIndexBuffer(plane_ibo_);

		//

	}
	void MRISliceViewer::OnUpdate(DeltaTime dt) {
		// Update logic for the slice viewer (if needed)
		for (auto& slice : slices_) {
			DrawSlice(slice);
		}
	}

	void MRISliceViewer::Render(bool standalone) {
		bool standalone_3D = false;
		if (standalone_3D)
			ImGui::Begin("Slice Viewer 3D Controls");

		bool opened = true;
		if (!standalone_3D) opened = ImGui::CollapsingHeader("Slice Viewer 3D Controls");
		if (opened) {

			// We have 3 transforms

			// We need to control each of the transforsm
			for (auto& slice : slices_) {
				GUI::RenderTransformSettings(slice.transform);
			}


		}

		if (standalone_3D)
			ImGui::End();


		if (standalone) ImGui::Begin("MRI Slice Viewer");
		
		
		ImGui::Text("MRI Slice Viewer - (Functionality to be implemented)");
	
		
		// TODO : Hvordan implementerer
		
		if (standalone) ImGui::End();
	}

	void MRISliceViewer::DrawSlice(Slice& slice) {
		RenderCommand cmd;

		cmd.VAOPtr = plane_vao_.get();
		cmd.ShaderPtr = slice_shader_.get();
		cmd.Mode = DrawMode::DRAW_ELEMENTS;
		cmd.target_viewport = ViewportType::MRIViewport;
		//cmd.TextureBindings.push_back({ mri_image_->GetTextureID(), 0, nullptr }); // Bind the MRI texture to slot 0

		// Set the transform uniform
		cmd.Transform = slice.transform.GetMatrix();
		

		//Renderer::Submit(cmd);
	};

}