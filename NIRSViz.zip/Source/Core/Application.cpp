#include "pch.h"

#include "Core/Application.h"
#include "Core/AssetManager.h"
#include "Renderer/Renderer.h"
#include "Renderer/ViewportManager.h"
#include <GLFW/glfw3.h>
#include "Core/AssetRegistry.h"

#include "Core/FileDialogService.h"

Application* Application::sInstance = nullptr;
Application::Application(const ApplicationSpecification& spec) : specification_(spec) {
	sInstance = this;


	// Set working directory here// Check if the WorkingDirectory string is NOT empty.
	if (specification_.working_directory.empty()) {
		// If it's not empty, set the current path to the specified directory.
		// Note: You might want to add error handling here in case the path is invalid.
		specification_.working_directory = std::string(spec.args.args[0]); // Default to the executable's directory
	}

	NVIZ_INFO("Application : {}", specification_.name);
	NVIZ_INFO("\tWorking Directory : {}", specification_.working_directory);

	// Exe is in out/build/x64-debug — go up 3 levels to reach the project root
	auto exe_dir = std::filesystem::path(specification_.working_directory).parent_path();
	auto assets_path = exe_dir.parent_path().parent_path().parent_path() / "Assets";
	AssetRegistry::Init(assets_path);
	
	FileDialogService::Init();
	
	WindowSpecification window_spec;
	window_spec.title = spec.name;
	window_spec.width = 1280;
	window_spec.height = 720;
	window_spec.resizeable = true;
	window_spec.vsync = true;

	window_ = CreateRef<Window>(window_spec);
	window_->SetEventCallback(BIND_EVENT_FN(Application::OnEvent));

	Renderer::Init();
	ViewportManager::Init();


	// --- Services ---> Data Ownership
	snirf_service_ = SNIRFService();
	anatomy_service_ = AnatomyService();


	// --- Systems
	gui_system_ = system_manager_.AddSystem<ImGuiSystem>();
	auto file_system = system_manager_.AddSystem<FileSystem>();
	auto channel_selector = system_manager_.AddSystem<ChannelSelectorSystem>(*file_system);
	auto plotting_system = system_manager_.AddSystem<PlottingSystem>(
		*channel_selector, 
		*file_system);
	auto anatomy_system = system_manager_.AddSystem<AnatomySystem>();
	auto probe_system = system_manager_.AddSystem<ProbeSystem>(
		*anatomy_system, 
		*file_system);
	auto voxel_system = system_manager_.AddSystem<VoxelSystem>();
	
	// Projection System - pass systems directly, they'll upcast automatically
	auto projection_system = system_manager_.AddSystem<ProjectionSystem>(
		*anatomy_system,   
		*channel_selector, 
		*plotting_system,  
		*plotting_system,
		*probe_system);    
	
	auto biosingal_system = system_manager_.AddSystem<BiosignalPlottingSystem>(*file_system);
	auto control_panel_system_ = system_manager_.AddSystem<ControlPanelSystem>(*this);
	auto mri_system = system_manager_.AddSystem<MRISystem>();

	// Register
	plotting_system->RegisterProjectionTimeSubscriber(projection_system);

	// TODO : We need some way to call application-> close globally. 
}

Application::~Application()
{
	Renderer::Shutdown();
}

void Application::Run()
{
	while (running_)
	{
		double time = (double)glfwGetTime();
		DeltaTime delta_time = time - last_time_;
		last_time_ = time;

		if (!minimized_)
		{
			window_->OnUpdate(delta_time);

			Renderer::BeginScene();

			for (auto& system : system_manager_)
				system->OnUpdate(delta_time);


			Renderer::ExecuteQueue();

			gui_system_->Begin();

			for (auto& system : system_manager_)
				system->OnGUIRender();

			gui_system_->End();
		}
	}
}

void Application::Close()
{
	running_ = false;
}

void Application::OnEvent(Event& e)
{
	EventDispatcher dispatcher(e); // This event is called from the window when an event occurs
	dispatcher.Dispatch<WindowCloseEvent>(
		BIND_EVENT_FN(Application::OnWindowClose));
	dispatcher.Dispatch<WindowResizeEvent>(
		BIND_EVENT_FN(Application::OnWindowResize));

	for (auto it = system_manager_.begin(); it != system_manager_.end(); ++it)
	{
		if (e.handled)
			break;
		(*it)->OnEvent(e);
	}
}

bool Application::OnWindowClose(WindowCloseEvent& e)
{
	running_ = false;
	return true;
}

bool Application::OnWindowResize(WindowResizeEvent& e)
{
	if (e.GetWidth() == 0 || e.GetHeight() == 0)
	{
		minimized_ = true;
		return false;
	}

	minimized_ = false;
	Renderer::OnWindowResize(e.GetWidth(), e.GetHeight());

	return false;
}
